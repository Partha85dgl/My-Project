﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Assignment_14_593284_Parthasarathy
{
    class Program
    {
        static void Main(string[] args)
        {
            int jointUser = 2;
            for (int i = 0; i < jointUser; i++)
            {
                Account account = new Account();
                
                Task[] taskArray = { Task.Factory.StartNew(() => account.Deposit(1000)),
                                     Task.Factory.StartNew(() => account.Withdrawal(100)),
                                     Task.Factory.StartNew(() => account.Withdrawal(500)),
                                     Task.Factory.StartNew(() => account.Deposit(1000)),
                                     Task.Factory.StartNew(() => account.Withdrawal(1000))};

                Task.WaitAll(taskArray);
                    
                Console.WriteLine(account.Balance); // should be 400

                Console.ReadLine();

            }
        }
    }

    public class Account
    {
        public int AccountNumber { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public decimal Balance { get; set; }

        static object depositlocker = new object();
        static object withdrawlocker = new object();
        public void Deposit(decimal amount)
        {
            Monitor.Enter(depositlocker);
            try
            {
                this.Balance += amount;
                Console.WriteLine($"Deposited: {amount}; Balance: {this.Balance} ");
            }
            finally
            {
                Monitor.Exit(depositlocker);
            }
        }
        public void Withdrawal(decimal amount)
        {
            Monitor.Enter(withdrawlocker);
            try
            {
                this.Balance -= amount;
                Console.WriteLine($"Withdrawl: {amount}; Balance: {this.Balance} ");
            }
            finally
            {
                Monitor.Exit(withdrawlocker);
            }
            

        }
    }
}
