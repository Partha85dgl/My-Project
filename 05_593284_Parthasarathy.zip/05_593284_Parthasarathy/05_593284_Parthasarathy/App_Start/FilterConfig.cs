﻿using System.Web;
using System.Web.Mvc;

namespace 05_593284_Parthasarathy
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
