﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_13_593284_Parthasarathy
{
    public class Program
    {
        static void Main(string[] args)
        {

            List<Person> personList = new List<Person>();
            personList.Add(new Professor("Vinoth", 5));
            personList.Add(new Professor("Kalai", 1));
            personList.Add(new Professor("Karthi", 2));
            personList.Add(new Professor("Sarathy", 4));
            personList.Add(new Student("Tarun", 99));
            personList.Add(new Student("Aarav", 70));
            personList.Add(new Student("Nitin", 90));
            personList.Add(new Student("Krish", 84));

            var outstandingList = personList.Where(x => x.IsOutstanding()).ToList();

            foreach (var person in outstandingList)
            {
                if(person.GetType() == typeof(Student))
                {
                    ((Student)person).Display();
                }
                else
                {
                    ((Professor)person).Print();
                }
            }

            Console.ReadLine();
        }
    }

    public abstract class Person
    {
        public string Name { get; set; }
        public Person()
        {

        }
        public Person(string name)
        {
            this.Name = name;
        }

        public abstract bool IsOutstanding();

    }
    public class Professor : Person
    {
        public int BooksPublished { get; set; }

        public Professor()
        {

        }
        public Professor(string Name, int booksPublished) : base(Name) {
            BooksPublished = booksPublished;
        }

        public void Print()
        {
            Console.WriteLine($" Professor - Name : {this.Name} and Books published : {this.BooksPublished}");
        }

        public override bool IsOutstanding()
        {
            return (this.BooksPublished > 4);
        }

    }

    public class Student : Person
    {
        public double Percentage { get; set; }

        public Student()
        {

        }
        public Student(string Name, double percentage) : base(Name)
        {
            Percentage = percentage;
        }

        public void Display()
        {
            Console.WriteLine($" Student - Name : {this.Name} and Percentage : {this.Percentage}%");
        }

        public override bool IsOutstanding()
        {
            return (this.Percentage > 85);
        }

    }
}
