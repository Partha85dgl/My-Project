﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using _23_593284_Parthasarathy_POPS_WebAPI.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using System.Web.Http;
using _23_593284_Parthasarathy_POPS_WebAPI.Models;
using System.Web.Http.Results;

namespace _23_593284_Parthasarathy_POPS_WebAPI.Controllers.Tests
{
    [TestClass()]
    public class SupplierControllerTest
    {
        SuppliersController controller = new SuppliersController();
        Mock<SuppliersController> mockController = new Mock<SuppliersController>();


        [TestInitialize]
        public void TestInitialize()
        {
            IHttpActionResult result = new OkResult(mockController.Object);
            mockController.Setup(x => x.GetSuppliers()).Returns(result);
        }

        [TestCleanup]
        public void TestCleanup()
        {

        }

        [TestMethod()]
        public void GetSuppliersTest()
        {
            var result = controller.GetSuppliers() as IHttpActionResult;
            Assert.IsNotNull(result);
            Assert.AreEqual(result.GetType(), typeof(IQueryable<Supplier>));
        }

        [TestMethod()]
        public void GetSupplierByIdTest()
        {
            var result = controller.GetSupplierById("1") as IHttpActionResult;
            Assert.IsNotNull(result);
            Assert.AreEqual(result.GetType(), typeof(Supplier));

            Assert.Fail();
        }

        [TestMethod()]
        public void UpdateSupplierTest()
        {
            var result = controller.UpdateSupplier("1", new Supplier { SUPLNO = "1", SUPLNAME = "Partha", SUPLADDR = "Chennai" });
            Assert.IsTrue(true);
        }

        [TestMethod()]
        public void CreateSupplierTest()
        {
            var result = controller.CreateSupplier(new Supplier { SUPLNO = "1", SUPLNAME = "Partha", SUPLADDR = "Chennai" });
            Assert.IsTrue(true);
           
        }

        [TestMethod()]
        public void DeleteSupplierTest()
        {
            var result = controller.DeleteSupplier("1");
            Assert.IsTrue(true);
        }
    }
}