﻿using System.Threading.Tasks;
using _23_484555_VinothKumarKannan_POPS_WebAPI.Models;
using System.Net.Http;
using System;
using System.Net.Http.Headers;

namespace _23__POPS_WebAPI_Client
{
    class Program
    {


        static void Main(string[] args)
        {
            RunPOPsWebAPI().GetAwaiter().GetResult();
        }

        static async Task RunPOPsWebAPI()
        {
            using (HttpClient Client = new HttpClient())
            {
                Client.BaseAddress = new Uri("http://localhost:59697/");
                Client.DefaultRequestHeaders.Accept.Clear();
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                SUPPLIER Supplier = new SUPPLIER
                {
                    SUPLNAME = "Test1",
                    SUPLADDR = "22-30-265,Velachery, Chennai",
                    SUPLNO = "1"
                };

                HttpResponseMessage Response = await Client.PostAsync()
                Response.EnsureSuccessStatusCode();



            }

           


        }
    }
}
