﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using _23_593284_Parthasarathy_POPS_WebAPI.Models;

namespace _23_593284_Parthasarathy_POPS_WebAPI.Controllers
{

    [RoutePrefix("api/v1/Suppliers")]
    public class SuppliersController : ApiController
    {
        private PODbEntities db = new PODbEntities();

        [Route("")]
        public IHttpActionResult GetSuppliers()
        {
            return Ok(db.Suppliers.ToList());
        }

        [Route("id:int")]
        [ResponseType(typeof(Supplier))]
        public IHttpActionResult GetSupplierById(string id)
        {
            Supplier supplier = db.Suppliers.Find(id);
            if (supplier == null)
            {
                return NotFound();
            }

            return Ok(supplier);
        }

        [HttpPut]
        [Route("id:int")]
        public IHttpActionResult UpdateSupplier(string id, [FromBody]Supplier supplier)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != supplier.SUPLNO)
            {
                return BadRequest();
            }

            db.Entry(supplier).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SupplierExist(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        [HttpPost]
        [Route("Supplier")]
        public IHttpActionResult CreateSupplier(Supplier supplier)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Suppliers.Add(supplier);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (SupplierExist(supplier.SUPLNO))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = supplier.SUPLNO }, supplier);
        }

        [HttpDelete]
        [Route("id:int")]
        public IHttpActionResult DeleteSupplier(string id)
        {
            Supplier supplier = db.Suppliers.Find(id);
            if (supplier == null)
            {
                return NotFound();
            }

            db.Suppliers.Remove(supplier);
            db.SaveChanges();

            return Ok(supplier);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool SupplierExist(string id)
        {
            return db.Suppliers.Any(e => e.SUPLNO == id);
        }
    }
}