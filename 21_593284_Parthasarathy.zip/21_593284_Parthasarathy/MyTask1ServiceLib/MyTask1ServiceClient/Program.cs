﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MyTask1ServiceProxy;

namespace MyTask1ServiceClient
{
    class Program
    {
        static void Main(string[] args)
        {

            //Proxy could be generated using many options. 
            //1. Add Service Referennce
            //2. svcutil.exe 
            //3. ClientBase

            //I am using option 3 as it is the best practice to use. 
            MyServiceProxy proxy = new MyServiceProxy();
            proxy.SayHello("Vinoth");
            proxy.TodayProgram("Vinoth");


        }
    }
}
