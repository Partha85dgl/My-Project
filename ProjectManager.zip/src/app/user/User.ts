
export class User {

  firstName:string;
  lastName:string;
  employeeID: string;
  userID:number;
    
  // constructor(firstName, lastName, employeeID)
  // {
  // this.firstName = firstName; 
  // this.lastName = lastName;
  // this.employeeID = employeeID;
  // }
}