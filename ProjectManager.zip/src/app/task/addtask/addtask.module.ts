import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjectModalComponent } from '../modal/project-modal/project-modal.component';
import { TaskPopupComponent } from '../modal/task-modal/task-popup.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: []
})
export class AddtaskModule { }
