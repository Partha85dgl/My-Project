import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewtaskComponent } from './viewtask.component';
import { ProjectModalComponent } from '../modal/project-modal/project-modal.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: []
})
export class ViewtaskModule { }
