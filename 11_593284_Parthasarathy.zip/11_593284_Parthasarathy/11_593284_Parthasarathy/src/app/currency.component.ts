﻿import { Component } from '@angular/core'

@Component({
    selector: 'currency-page',
    templateUrl: './currency.component.html'
})

export class CurrencyComponent { }