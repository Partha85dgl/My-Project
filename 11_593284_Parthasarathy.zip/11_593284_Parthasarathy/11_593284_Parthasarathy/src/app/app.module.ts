import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { HomeComponent } from './home.component';
import { WeatherComponent } from './weather.component';
import { MovieComponent } from './movie.component';
import { CurrencyComponent } from './currency.component';

const appRoutes: Routes = [
    { path: 'home', component: HomeComponent },
    { path: 'weather', component: WeatherComponent },
    { path: 'movie', component: MovieComponent },
    { path: 'currency', component: CurrencyComponent },
    { path: 'home', redirectTo: '/menu', pathMatch: 'full' }
];

@NgModule({
    imports: [
        BrowserModule,
        HttpModule,
        RouterModule.forRoot(appRoutes)
    ],
    declarations: [AppComponent, HomeComponent, WeatherComponent, MovieComponent, CurrencyComponent],
    bootstrap: [AppComponent]
})
export class AppModule { }
