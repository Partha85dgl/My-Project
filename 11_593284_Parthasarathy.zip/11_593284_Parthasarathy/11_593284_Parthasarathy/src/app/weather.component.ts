﻿import { Component, OnInit } from '@angular/core'
import { WeatherService } from './weather.service'

@Component({
    selector: 'weather-page',
    templateUrl: './weather.component.html'
})

export class WeatherComponent implements OnInit {

    weather: any[];

    constructor(private _weatherService: WeatherService) { }
    ngOnInit() {
        this._weatherService.getWeather().subscribe(resWeatherData => this.weather = resWeatherData);
    }
}