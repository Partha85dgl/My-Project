﻿import { Component } from '@angular/core'

@Component({
    selector: 'weather-page',
    templateUrl: './weather.component.html'
})

export class WeatherComponent { }