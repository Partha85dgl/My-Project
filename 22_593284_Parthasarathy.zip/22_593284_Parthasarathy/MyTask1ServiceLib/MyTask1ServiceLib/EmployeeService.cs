﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using WCFService2.ServiceContracts;
using WCFService2.DataContracts;

namespace WCFService2
{
    public class EmployeeService : IEmployeeService
    {
        public bool AddEmployee(Employee employee)
        {
            if (employee != null)
            {
                return DataAccess.AddEmployee(employee);
            }
            else
            {
                throw new FaultException("Employee is either empty or not available");
            }
        }

        public bool DeleteEmployee(int empId)
        {
            if (empId != int.MinValue)
            {
                return DataAccess.DeleteEmployee(empId);
            }
            else
            {
                throw new FaultException("Employee is either empty or not passed");
            }
        }

        public Employee RetrieveEmployeeById(int empId)
        {
            if (empId != int.MinValue)
            {
                return DataAccess.RetrieveEmployeeById(empId);
            }
            else
            {
                throw new FaultException("Employee is either empty or not available");
            }
        }

        public List<Employee> RetrieveEmployees()
        {
            return DataAccess.RetrieveEmployees();
        }

        public bool UpdateEmployee(int EmpId, Employee employee)
        {
            if (employee != null && EmpId != int.MinValue)
            {
                return DataAccess.UpdateEmployee(EmpId, employee);
            }
            else
            {
                throw new FaultException("Employee is either empty or not available");
            }
        }
    }
}
