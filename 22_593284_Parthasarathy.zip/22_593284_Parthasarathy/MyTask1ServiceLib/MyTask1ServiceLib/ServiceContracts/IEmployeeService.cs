﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using WCFService2.DataContracts;

namespace WCFService2.ServiceContracts
{
    [ServiceContract]
    public interface IEmployeeService
    {
        [OperationContract]
        bool AddEmployee(Employee employee);

        [OperationContract]
        List<Employee> RetrieveEmployees();


        [OperationContract]
        Employee RetrieveEmployeeById(int empId);


        [OperationContract]
        bool UpdateEmployee(int EmpId, Employee employee);

        [OperationContract]
        bool DeleteEmployee(int empId);
    }
}
