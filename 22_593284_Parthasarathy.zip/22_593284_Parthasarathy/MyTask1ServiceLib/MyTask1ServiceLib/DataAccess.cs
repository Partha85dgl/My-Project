﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WCFService2.DataContracts;

namespace WCFService2
{
    public class DataAccess
    {
        public const string ConnectionString = @"Data Source=DOTNET;Initial Catalog=VINOTH;Integrated Security=True";
        public static bool AddEmployee(Employee employee )
        {
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                StringBuilder insertQuery = new StringBuilder();
                insertQuery.Append("INSERT INTO Employee (LastName, FirstName, Designation, Location, Company) ");
                insertQuery.Append($"VALUES ( @LNAME, @FNAME, @DESGN, @LOC, @COMP");

                SqlCommand cmd = new SqlCommand(insertQuery.ToString(), con);
                cmd.Parameters.AddRange(new List<SqlParameter> {
                    new SqlParameter{ ParameterName = "@LNAME", Value= employee.LastName},
                    new SqlParameter{ ParameterName = "@FNAME", Value= employee.FirstName},
                    new SqlParameter{ ParameterName = "@DESGN", Value= employee.Designation},
                    new SqlParameter{ ParameterName = "@LOC", Value= employee.Location},
                    new SqlParameter{ ParameterName = "@COMP", Value= employee.Company},
                }.ToArray());

               int rowsaffected =  cmd.ExecuteNonQuery();
                if( rowsaffected > 0)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool UpdateEmployee(int empID, Employee employee)
        {
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                StringBuilder updateQuery = new StringBuilder();
                updateQuery.Append("UPDATE Employee SET LastName = @LNAME, FirstName = @FNAME, Designation= @DESGN");
                updateQuery.Append(", Location = @LOC, Company = @COMP");

                SqlCommand cmd = new SqlCommand(updateQuery.ToString(), con);
                cmd.Parameters.AddRange(new List<SqlParameter> {
                    new SqlParameter{ ParameterName = "@LNAME", Value= employee.LastName},
                    new SqlParameter{ ParameterName = "@FNAME", Value= employee.FirstName},
                    new SqlParameter{ ParameterName = "@DESGN", Value= employee.Designation},
                    new SqlParameter{ ParameterName = "@LOC", Value= employee.Location},
                    new SqlParameter{ ParameterName = "@COMP", Value= employee.Company},
                }.ToArray());

                int rowsaffected = cmd.ExecuteNonQuery();
                if (rowsaffected > 0)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool DeleteEmployee(int empID)
        {
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                StringBuilder updateQuery = new StringBuilder();
                updateQuery.Append("DELETE FROM Employee WHERE EmployeeID = @EMPID");

                SqlCommand cmd = new SqlCommand(updateQuery.ToString(), con);
                cmd.Parameters.AddRange(new List<SqlParameter> {
                    new SqlParameter{ ParameterName = "@EMPID", Value= empID},
                   
                }.ToArray());

                int rowsaffected = cmd.ExecuteNonQuery();
                if (rowsaffected > 0)
                {
                    return true;
                }
            }
            return false;
        }

        public static List<Employee> RetrieveEmployees()
        {
            return null;
        }


        public static Employee RetrieveEmployeeById(int empId)
        {
            return null;
        }

    }
}
