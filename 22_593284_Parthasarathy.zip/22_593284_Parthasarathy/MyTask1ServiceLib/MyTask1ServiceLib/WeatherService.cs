﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using WCFService2.ServiceContracts;
using WCFService2.DataContracts;

namespace WCFService2
{
    public class WeatherService : IWeatherService
    {
        public float CelciusToFahrenheit(Employee employee)
        {
            return 0.0f;
        }

        public float FahrenheitToCelsius()
        {
            return 0.0f;
        }
    }
}
