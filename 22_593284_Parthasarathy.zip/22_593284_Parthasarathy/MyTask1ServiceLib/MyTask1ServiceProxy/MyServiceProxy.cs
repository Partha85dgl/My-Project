﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using WCFService2.ServiceContracts;
using WCFService2.DataContracts;

namespace MyTask1ServiceProxy
{
    public class MyServiceProxy : ClientBase<IEmployeeService>, IEmployeeService
    {
        public bool AddEmployee(Employee employee)
        {
           return  base.Channel.AddEmployee(employee);
        }

        public bool DeleteEmployee(int empId)
        {
            return base.Channel.DeleteEmployee(empId);
        }

        public Employee RetrieveEmployeeById(int empId)
        {
            return base.Channel.RetrieveEmployeeById(empId);
        }

        public List<Employee> RetrieveEmployees()
        {
            return base.Channel.RetrieveEmployees();
        }
       
        public bool UpdateEmployee(int EmpId, Employee employee)
        {
            return base.Channel.UpdateEmployee(EmpId, employee);
        }
    }
}