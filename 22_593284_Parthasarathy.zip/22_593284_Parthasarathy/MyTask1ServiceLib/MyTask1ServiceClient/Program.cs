﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MyTask1ServiceProxy;
using WCFService2.DataContracts;

namespace MyTask1ServiceClient
{
    class Program
    {
        static void Main(string[] args)
        {

            //Proxy could be generated using many options. 
            //1. Add Service Referennce
            //2. svcutil.exe 
            //3. ClientBase

            //I am using option 3 as it is the best practice to use. 
            MyServiceProxy proxy = new MyServiceProxy();

            proxy.AddEmployee(new Employee { FirstName = "Vinoth Kumar", LastName = "Kannan", Designation = "Manager", Location = "Chennai", Company = "Cognizant" });

            proxy.UpdateEmployee(EmpId:1, employee: new Employee { FirstName = "Vinoth Kumar", LastName = "Kannan", Designation = "Manager", Location = "Chennai", Company = "Cognizant" });

            proxy.DeleteEmployee(empId: 1);

            var result = proxy.RetrieveEmployees();

            var result1 = proxy.RetrieveEmployeeById(empId: 1);
        }
    }
}
