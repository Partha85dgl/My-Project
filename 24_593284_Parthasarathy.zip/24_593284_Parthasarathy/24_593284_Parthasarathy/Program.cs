﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _24_593284_Parthasarathy
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Exercise 1

            Console.WriteLine("Please enter the number of elements in the array.");
            int LengthOfArray = Convert.ToInt32(Console.ReadLine());
            int[] UserInputArray = new int[5] { 3,6,9,12,15};
            //Console.WriteLine("Please enter the elements of the array.");

            //for (int i = 0; i < LengthOfArray; i++)
            //{
            //    UserInputArray[i] = Convert.ToInt32(Console.ReadLine());
            //}

            int[] FinalArray = UserInputArray.Where(x => (x * x * x) > 100 && (x * x * x) < 1000).ToArray();

            foreach (var Element in FinalArray)
            {
                Console.WriteLine("Cube of the number {0}", Element);
            }

            

            #endregion

            Console.WriteLine("\n\n\n------------Exercise 2---------------\n\n\n");

            #region Exercise 2

            List<Participant> ListofParticipant = new List<Participant>
            {
                new Participant { ParticipantName = "A", Country = "India"},
                new Participant { ParticipantName = "B", Country = "Australia"},
                new Participant { ParticipantName = "C", Country = "USA"},
                new Participant { ParticipantName = "D", Country = "PAK"},
                new Participant { ParticipantName = "E", Country = "UK"},
                new Participant { ParticipantName = "F", Country = "Germany"},
                new Participant { ParticipantName = "G", Country = "Finland"},
                new Participant { ParticipantName = "H", Country = "China"},
                new Participant { ParticipantName = "I", Country = "India"},
                new Participant { ParticipantName = "J", Country = "Spain"}


            };

            int Numberofparticipants = ListofParticipant.Count();

            List<Participant> FirstHalf = ListofParticipant.Take(Numberofparticipants / 2).ToList();

            List<Participant1> SecondHalf = ListofParticipant.Except(FirstHalf).Select(x => new Participant1
            {
                OpponentName = x.ParticipantName,
                OpponentCountry = x.Country
            }).ToList();

            //Applying cross join
            var FinalList = from a in FirstHalf
                            from b in SecondHalf
                            where a.Country != b.OpponentCountry
                            select new { a.ParticipantName, a.Country, b.OpponentName, b.OpponentCountry };

            foreach (var Match in FinalList)
            {
                Console.WriteLine("Match is between {0}({1}) vs {2}({3})", Match.ParticipantName, Match.Country, Match.OpponentName, Match.OpponentCountry);
            }
            Console.WriteLine("Total Matches : {0}", FinalList.Count());

            #endregion

            Console.WriteLine("\n\n\n------------Exercise 3---------------\n\n\n");

            #region Exercise 3

            List<Order> ListofOrders = new List<Order>()
            {
                new Order {OrderID = 1, ItemName = "P", OrderDate = DateTime.Now, Quantity = 65},
                new Order {OrderID = 2, ItemName = "Q", OrderDate = DateTime.Now.AddYears(2), Quantity = 650},
                new Order {OrderID = 3, ItemName = "R", OrderDate = DateTime.Now.AddYears(-3), Quantity = 650},
                new Order {OrderID = 4, ItemName = "S", OrderDate = DateTime.Now.AddMonths(-6), Quantity = 12},
                new Order {OrderID = 5, ItemName = "T", OrderDate = DateTime.Now.AddDays(-20), Quantity = 740},
                new Order {OrderID = 6, ItemName = "U", OrderDate = DateTime.Now.AddDays(48), Quantity = 23},
                new Order {OrderID = 7, ItemName = "V", OrderDate = DateTime.Now.AddMinutes(1123), Quantity = 1200},
                new Order {OrderID = 8, ItemName = "W", OrderDate = DateTime.Now.AddHours(8), Quantity = 1800},
                new Order {OrderID = 9, ItemName = "X", OrderDate = DateTime.Now.AddYears(1), Quantity = 650},

            };

            var FinalOrderList = ListofOrders.OrderByDescending(x => x.OrderDate.Date).ThenByDescending(y => y.Quantity).ToList();

            foreach (var Order in FinalOrderList)
            {
                Console.WriteLine("Order Details :- Order Id : {0},\t Item Name : {1},\t Order Date : {2},\t Quantity : {3}", Order.OrderID, Order.ItemName, Order.OrderDate, Order.Quantity);

            }
            #endregion

            Console.WriteLine("\n\n\n------------Exercise 4---------------\n\n\n");

            #region Exercise 4

            var exec4Result = ListofOrders.GroupBy(x => x.OrderDate.Month)
                                            .OrderByDescending(x => x.Key)
                                            .Select(x => new { Month = x.Key, Count = x.Count() });
            foreach(var item in exec4Result)
            {
                Console.WriteLine($"Total item for Month {item.Month} : {item.Count}");
            }
            #endregion


            #region Exercise 5

            var items = new List<Item> {
                new Item{ ItemName="P", Price= 100},
                new Item{ ItemName="Q", Price= 200},
                new Item{ ItemName="R", Price= 300},
                new Item{ ItemName="S", Price= 400},
                new Item{ ItemName="T", Price= 500},
                new Item{ ItemName="U", Price= 600}
            };

            var exec5Result = ListofOrders.Join(items, x => x.ItemName, y => y.ItemName, 
                                                (x, y) => new {
                                                    Id = x.OrderID,
                                                    Name = x.ItemName,
                                                    OrderDate = x.OrderDate,
                                                    TotalPrice = (x.Quantity * y.Price)
                                                });

            foreach(var item in exec5Result)
            {
                Console.WriteLine($"OrderId : {item.Id}, Name : {item.Name},  Total Price : {item.TotalPrice}");
            }



            #endregion

            #region Exercise 6
            var result = UserInputArray.Where(x => x % 2 == 0).ToArray().Length;


            Console.WriteLine("Count of Even Numbers in the Array : {0}", result);
            #endregion

            #region Exercise 9


            var Result = UserInputArray.Where(x => x % 2 == 0).ToArray().Length;

            
            Console.WriteLine("Count of Even Numbers in the Array : {0}", result);





            #endregion

            Console.ReadLine();

        }

        #region Exercise 2 Classes

        public class Participant
        {
            public string ParticipantName { get; set; }
            public string Country { get; set; }

        }

        public class Participant1
        {
            public string OpponentName { get; set; }
            public string OpponentCountry { get; set; }

        }

        #endregion

        #region Exercise 3 Classes

        public class Order
        {
            public int OrderID { get; set; }
            public string ItemName { get; set; }
            public DateTime OrderDate { get; set; }
            public int Quantity { get; set; }
        }

        public class Item
        {
            public string ItemName { get; set; }
            public Decimal Price { get; set; }
        }
        #endregion
    }
}
