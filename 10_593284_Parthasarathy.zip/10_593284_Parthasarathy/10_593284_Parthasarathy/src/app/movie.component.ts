﻿import { Component } from '@angular/core'

@Component({
    selector: 'movie-page',
    templateUrl: './movie.component.html'
})

export class MovieComponent { }