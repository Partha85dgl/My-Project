﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace _18_593284_Parthasarathy.Models
{
    public  class DataAccess
    {
        public const string ConnectionString = @"Data Source=DOTNET;Initial Catalog=VINOTH;Integrated Security=True";
        public static List<ProductDetails> GetAllProductDetails()
        {
            List<ProductDetails> products = new List<ProductDetails>();
            using(SqlConnection con = new SqlConnection(ConnectionString))
            {
                if(con.State != System.Data.ConnectionState.Open)
                {
                    con.Open();
                }
                string selectQuery = "Select * from ProductDetails";
                SqlCommand cmd = new SqlCommand(selectQuery, con);
                var result = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                while (result.Read())
                {
                    products.Add(new ProductDetails
                    {
                        ProductId = result.GetInt32(0),
                        ProductName = result.GetString(1),
                        SupplierId = result.GetInt32(2)
                    });
                }
            }
            return products;
        }

        public static List<SupplierInfo> GetAllSupplierInfo()
        {
            List<SupplierInfo> suppliers = new List<SupplierInfo>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                if (con.State != System.Data.ConnectionState.Open)
                {
                    con.Open();
                }
                string selectQuery = "Select * from SupplierInfo";
                SqlCommand cmd = new SqlCommand(selectQuery, con);
                var result = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                while (result.Read())
                {
                    suppliers.Add(new SupplierInfo
                    {
                        SupplierId = result.GetInt32(0),
                        SupplierName = result.GetString(1),
                        Address = result.GetString(2),
                        City = result.GetString(3),
                        ContactNumber = result.GetInt32(4),
                        Email = result.GetString(5)
                    });
                }
            }
            return suppliers;
        }

    }
}