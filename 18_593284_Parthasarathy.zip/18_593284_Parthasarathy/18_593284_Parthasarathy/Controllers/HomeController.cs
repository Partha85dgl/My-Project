﻿using _18_484555_VinothKumarKannan.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace _18_593284_Parthasarathy.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
           var products =  DataAccess.GetAllProductDetails(); 
            return View(products);
        }

        public ActionResult Supplier()
        {
            var suppliers = DataAccess.GetAllSupplierInfo();
            return View(suppliers);
        }

    }
}