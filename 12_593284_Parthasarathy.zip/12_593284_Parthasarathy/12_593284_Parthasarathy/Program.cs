﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Assignment12_593284_Parthasarathy
{ 
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("2D ARRAY");
            TestArray2D();

            Console.WriteLine("Multiple Inheritance");
            TestMultiplInheritance();

            Console.WriteLine("Generic");
            TestGeneric();

            Console.WriteLine("Regular Expression");
            TestRegex();

            Console.ReadLine();
        }

        public static void TestArray2D()
        {
            int row = 3;
            int col = 3;
            int[,] objArray = new int[row,col];


            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    Console.Write(string.Format("{0} ", objArray[i, j]));
                }
                Console.Write(Environment.NewLine + Environment.NewLine);
            }
        }

        public static void TestMultiplInheritance()
        {
            BaseDto b = new BaseDto();
            b.DisplayName(); // Base class output

            DerivedDto d = new DerivedDto();
            d.DisplayName(); //Derived class output

            BaseDto o = new DerivedDto();
            o.DisplayName(); //Derived Class output. 
        }

        public static void TestGeneric()
        {
            List<int> numList = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };

            var result = numList.Where(x => ((x % 3) == 0)).ToList();

            Console.WriteLine(string.Join(",", result));

        }

        public static void TestRegex()
        {
            string input = "parthasarathy.s3@cognizant.com";
            string input1 = "parthasarathy.s3@cognizant";
            Console.WriteLine($"Input 1: {input}");
            Console.WriteLine($"Output 1:  {input.IsEmail()}");

            Console.WriteLine($"Input 2: {input1}");
            Console.WriteLine($"Output 2:  {input1.IsEmail()}");
        }
    }

   
    public class BaseDto
    { 
        public virtual void DisplayName()
        {
            Console.WriteLine("Base Class Output");
        }
    }

    public class DerivedDto : BaseDto
    {
        public override void DisplayName()
        {
            Console.WriteLine("Derived Class Output");
        }

    }

    public static class StringExtension
    {
        public static bool IsEmail(this string value)
        {
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");

            return regex.IsMatch(value);
        }
    }
    
}
